/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.Scanner;
/**
 *
 * @author Luz Rodríguez
 */
public class ExamenCortoFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Ingrese frase para decifrar.");
        Scanner scan = new Scanner(System.in);
        String frase = scan.nextLine();
        
        System.out.println("Su frase es: " + frase);
        
        Poligono a1, b1, c1;
        
        a1 = new Triangulo(5,10,3,3,3); // Base, Altura, Lado1, Lado2, Lado3
        b1 = new Cuadrilatero(5,10,4,4,4,4); // Base, Altura, Lado1, Lado2, Lado3, Lado4
        c1 = new Pentagono(6,3.1,2.7);
    }
    
}
