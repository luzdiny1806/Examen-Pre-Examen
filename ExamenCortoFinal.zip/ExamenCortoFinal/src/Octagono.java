/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author luzdy
 */
public class Octagono implements Poligono{
    
    private double numeroLados;
    private double lado1;   
    private double apotema;
    
    public Octagono (double numeroLados, double lado1, double apotema){
        this.numeroLados = numeroLados;
        this.lado1 = lado1;
        this.apotema = apotema;
    }
    
    public double area(){
        return (this.numeroLados*this.lado1*apotema)/2;
    }
    public double perimetro(){
        return (this.numeroLados*this.lado1);
    }
    
}
