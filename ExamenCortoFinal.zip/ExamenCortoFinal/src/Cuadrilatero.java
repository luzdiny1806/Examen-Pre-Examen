/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author luzdy
 */
public class Cuadrilatero implements Poligono{
    private double base;
    private double altura;
    private double lado1;
    private double lado2;
    private double lado3;
    private double lado4;
    
    public Cuadrilatero (double base, double altura, double lado1, double lado2, double lado3, double lado4){
        this.base = base;
        this.altura = altura;
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
        this.lado4 = lado4;
    }
    
    public double area(){
        return this.altura * this.base;
    }
    public double perimetro(){
        return this.lado1 + this.lado2 + this.lado3 + this.lado4;
    }
}
