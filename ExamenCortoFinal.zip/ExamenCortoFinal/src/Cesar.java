
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author luzdy
 */
public class Cesar {
    
    public void cifrarCesar (String frase, int distancia){
        System.out.println("Ingrese frase para decifrar.");
        Scanner scan = new Scanner(System.in);
        String frase1 = scan.nextLine();
    }
    
    public void cifrarCesar(String frase, String alfabeto, int distancia){
        
    }
}
